# Development Phases

## Phase 1: Foundation

Goal: Basic app with one benchmark

Tasks:
- [ ] cargo new workbench
- [ ] Set up Cargo.toml (see 01-cargo-toml.md)
- [ ] Create folder structure
- [ ] Implement high-precision timer (QueryPerformanceCounter)
- [ ] Implement system info detection
- [ ] Create egui window with theme
- [ ] Build home view with system info
- [ ] Implement file enumeration benchmark
- [ ] Show single result

Deliverable: App shows system info, runs one benchmark

## Phase 2: Core Benchmarks

Goal: All disk and latency benchmarks

Tasks:
- [ ] Benchmark trait + runner
- [ ] Storage latency with percentiles
- [ ] Small file random read
- [ ] Metadata operations
- [ ] Directory traversal
- [ ] Large file sequential read
- [ ] Process spawn time
- [ ] Thread wake latency
- [ ] Progress reporting

Deliverable: All I/O benchmarks working

## Phase 3: CPU/Memory + UI

Goal: Complete benchmarks, polished results

Tasks:
- [ ] Single-thread compute
- [ ] Multi-thread compute
- [ ] Mixed workload
- [ ] Memory latency
- [ ] Memory bandwidth
- [ ] Running view with progress
- [ ] Results view with cards
- [ ] Category breakdown
- [ ] Detail panels

Deliverable: Full suite except graphics

## Phase 4: Scoring + Export

Goal: Scoring, JSON, comparison

Tasks:
- [ ] Scoring calculator
- [ ] Rating logic
- [ ] JSON export
- [ ] JSON import
- [ ] Comparison view
- [ ] Latency histogram
- [ ] Difference highlighting

Deliverable: Complete scoring and comparison

## Phase 5: Polish

Goal: Reports, graphics, release

Tasks:
- [ ] GPU detection
- [ ] Graphics benchmarks (optional)
- [ ] HTML report generation
- [ ] UI polish
- [ ] Error handling
- [ ] Release optimization
- [ ] Multi-machine testing

Deliverable: Release-ready application

## Key Code Patterns

### High-Precision Timer (Windows)
```rust
#[cfg(windows)]
pub fn precise_time_ns() -> u64 {
    use windows::Win32::System::Performance::*;
    let mut counter = 0i64;
    let mut frequency = 0i64;
    unsafe {
        QueryPerformanceCounter(&mut counter);
        QueryPerformanceFrequency(&mut frequency);
    }
    ((counter as u128 * 1_000_000_000) / frequency as u128) as u64
}
```

### Background Thread Pattern
```rust
enum BenchmarkMessage {
    Progress { progress: f32, message: String },
    TestComplete { result: TestResult },
    AllComplete { run: BenchmarkRun },
    Error { error: String },
}

// Use channels between UI and benchmark thread
let (tx, rx) = std::sync::mpsc::channel();
```

### Test File Location
- Use std::env::temp_dir() for test files
- Clean up after each benchmark
- Results in user documents folder
