# UI Design

## Colors

```rust
// Primary
const BG_PRIMARY: Color32 = Color32::from_rgb(248, 250, 252);   // #f8fafc
const BG_CARD: Color32 = Color32::WHITE;
const BG_DARK: Color32 = Color32::from_rgb(26, 26, 46);         // #1a1a2e

// Text
const TEXT_PRIMARY: Color32 = Color32::from_rgb(30, 41, 59);    // #1e293b
const TEXT_SECONDARY: Color32 = Color32::from_rgb(100, 116, 139); // #64748b

// Accent
const ACCENT: Color32 = Color32::from_rgb(15, 52, 96);          // #0f3460
const ACCENT_HOVER: Color32 = Color32::from_rgb(26, 74, 122);

// Ratings
const SCORE_EXCELLENT: Color32 = Color32::from_rgb(16, 185, 129);   // green
const SCORE_GOOD: Color32 = Color32::from_rgb(59, 130, 246);        // blue
const SCORE_ACCEPTABLE: Color32 = Color32::from_rgb(245, 158, 11);  // amber
const SCORE_POOR: Color32 = Color32::from_rgb(239, 68, 68);         // red
const SCORE_INADEQUATE: Color32 = Color32::from_rgb(127, 29, 29);   // dark red

// Neutral
const BORDER: Color32 = Color32::from_rgb(226, 232, 240);       // #e2e8f0
```

## Typography

- Headings: Inter SemiBold
- Body: Inter Regular
- Mono: JetBrains Mono

Sizes: Title 28px, Section 20px, Card 16px, Body 14px, Caption 12px, Score 36px

## Components

### Score Card (200x140px)
- Border radius: 8px
- Border: 1px #e2e8f0
- Background: white
- Score: 36px bold centered
- Progress bar: 8px height
- Rating badge at bottom

### Progress Bar
- Height: 8px (large) or 6px (small)
- Border radius: 4px
- Background: #e2e8f0
- Fill: rating color

### Rating Badge
- Padding: 8px x 4px
- Border radius: 4px
- Background: rating color 15% opacity
- Text: rating color 100%

## Views

### Home View
- App title + tagline
- System info card
- Test config checkboxes
- Run button (large, centered)
- Previous results dropdown

### Running View
- Overall progress bar
- Category list with status
- Current test name + progress
- Cancel button

### Results View
- Overall score card (large)
- 4 category cards in grid
- Expandable detail sections
- Export/Compare buttons

### Compare View
- Side-by-side score cards
- Category bar comparison
- Difference column with multipliers
- Key metrics table
